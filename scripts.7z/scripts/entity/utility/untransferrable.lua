
-- Don't remove or alter the following comment, it tells the game the namespace this script lives in. If you remove it, the script will break.
-- namespace UntransferrableEntity
UntransferrableEntity = {}

function UntransferrableEntity.isTransferrable()
    print ("not transferrable")
    return false
end
