package.path = package.path .. ";data/scripts/lib/?.lua;data/scripts/entity/merchants/?.lua"

-- Don't remove or alter the following comment, it tells the game the namespace this script lives in. If you remove it, the script will break.
-- namespace MidFactory
MidFactory = require ("factory")

MidFactory.minLevel = 4
MidFactory.maxLevel = 6
